# Descomplex MVP

MVP React + Firebase para organizar tarefas e diagnosticar a distribuição atual do tempo.

## Executar

1. Copie `.env.example` para `.env` e preencha as credenciais do seu projeto Firebase.
2. No Firebase Console, crie o banco **Cloud Firestore** (modo de produção) e habilite os provedores de login que deseja usar (e-mail/senha e/ou Google).
3. Publique as regras: `npx firebase-tools deploy --only firestore:rules --project SEU_PROJECT_ID`.
4. Instale as dependências com `npm install` e execute `npm run dev`.

O diagnóstico é mantido no cache local do navegador durante oscilações de rede e sincronizado com o Firestore assim que a conexão voltar. Se o banco ou as regras ainda não estiverem configurados, a aplicação informa o motivo exato em vez de apresentar uma mensagem genérica de conexão.

## Tríade do Tempo

O diagnóstico possui nove afirmações atuais, três para cada dimensão: **Urgente**, **Importante** e **Circunstancial**. Cada resposta (1–5) contribui apenas para sua dimensão. A participação de cada dimensão é `subtotal / soma dos três subtotais × 100`. O arredondamento usa o método dos maiores restos, então os percentuais exibidos sempre somam exatamente 100%.

As classificações das tarefas usam as mesmas dimensões. Os valores antigos `MEDIA` e `TRANQUILO` continuam aceitos para que tarefas existentes não sejam perdidas.
